(function(modules) {
    var installedModules = {};

    function __webpack_require__(moduleId) {
        if(installedModules[moduleId])
            return installedModules[moduleId].exports;
        var module = installedModules[moduleId] = {
            exports: {},
            id: moduleId,
            loaded: false
        };

        modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

        module.loaded = true;

        return module.exports;
    }

    __webpack_require__.m = modules;

    __webpack_require__.c = installedModules;

    __webpack_require__.p = "";

    return __webpack_require__(0);
})
([
    function(module, exports) {

        /*
         * 时间工具函数
         * 封装于 2015-07-07
         */
        (function(window){
            var v = {};
            v.isNull = function(value,msg){
                if (value == null || value == "" || value == "undefined" || value == undefined || value == "null" || value == "(null)" || value == 'NULL' || typeof(value) == 'undefined') {
                    api.toast({
                        msg: msg,
                        duration: 2000,
                        location: 'middle'
                    });
                    return true;
                } else {
                    value = value + "";
                    value = value.replace(/\s/g, "");
                    if (value == "") {
                        api.toast({
                            msg: msg,
                            duration: 2000,
                            location: 'middle'
                        });
                        return true;
                    }
                    return false;
                }
            };
            v.isPhone = function(value,msg){
                if(!this.isNull(value,"请输入手机号码")){
                    if (!/^1[3,4,5,7,8]\d{9}$/.test(value)) {
                        Tool.toast('手机号码不正确~');
                        return false;
                    }else{
                        return true;
                    }
                }else{
                    return false;
                }
            };
            v.isPwd = function(value,msg){
                if(!this.isNull(value,"密码不能为空")){
                    if (value.length < 6 || value.length>16) {
                        Tool.toast('密码长度必须大于6位');
                        return false;
                    }else if(value.length>16) {
                        Tool.toast('密码长度必须小于16位');
                        return false;
                    }else{
                        return true;
                    }
                }else{
                    return false;
                }
            };

            window.V = v;
        })(window);

    }
])



/*//验证手机号码合法性
//验证邮箱合法性
function validateEmail(email) {
    if (email) {
        if (!/^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/.test(email)) {
            Tool.toast('邮箱地址不正确~');
            return false;
        }
    } else {
        Tool.toast('请填写您的邮箱地址~');
        return false;
    }
    return true;
}
//验证密码合法性
function validatePassword(password) {
    if (!password) {
        Tool.toast('密码不能为空~');
        return false;
    } else if (password.length < 6) {
        Tool.toast('密码长度必须大于6位');
        return false;
    } else if (password.indexOf(' ') > -1) {
        Tool.toast('密码不能含有空格');
        return false;
    }
    return true;
}


/!*替换null字段*!/
function rmNull(data) {
    if (data && (data != 'undefined' || data != 'null')) {
        return data;
    } else {
        return '';
    }
}*/
