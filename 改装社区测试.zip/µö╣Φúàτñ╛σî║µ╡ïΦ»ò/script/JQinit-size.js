/**
 * @auter  546
 * @file init-size.js
 * @description 计算html元素的font-size,使1rem等于16px,方便快速开发 ，
 *              eg:设计稿的一个字号大小为28px---->则：font-size:1.75rem;
 *                 设计稿的一个宽度大小为750px---->则：width:;
 */
function remReSize() {
	var w = $(window).width();
	try {
		w = $(parent.window).width();
	} catch (ex) {};
	if (w > 640) {
		w = 640;
	};
	//html元素字体大小 = document根节点(html)宽度 * 100 / 设计图宽度 
	$('html').css('font-size', 16 / 640 * w + 'px');
};
remReSize();
//当窗体大小变化时，html字体大小随着变化
$(window).resize(remReSize);
$(document).ready(function() {
	remReSize();
});
//避免页面js延迟加载
for (var i = 0; i < 3; i++) {
	setTimeout(remReSize, 100 * i);
};