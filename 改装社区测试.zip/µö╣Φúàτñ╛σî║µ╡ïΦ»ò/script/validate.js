

//验证手机号码合法性
function validatePhone(phone) {
    if (phone) {
        if (!/^1[3,4,5,7,8]\d{9}$/.test(phone)) {
            Tool.toast('手机号码不正确~');
            return false;
        }
    } else {
        Tool.toast('请填写您的手机号码~');
        return false;
    }
    return true;
}
//验证邮箱合法性
function validateEmail(email) {
    if (email) {
        if (!/^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/.test(email)) {
            Tool.toast('邮箱地址不正确~');
            return false;
        }
    } else {
        Tool.toast('请填写您的邮箱地址~');
        return false;
    }
    return true;
}
//验证密码合法性
function validatePassword(password) {
    if (!password) {
        Tool.toast('密码不能为空~');
        return false;
    } else if (password.length < 6) {
        Tool.toast('密码长度必须大于6位');
        return false;
    } else if (password.indexOf(' ') > -1) {
        Tool.toast('密码不能含有空格');
        return false;
    }
    return true;
}
//验证是否为空
function is_define(value) {
    if (value == null || value == "" || value == "undefined" || value == undefined || value == "null" || value == "(null)" || value == 'NULL' || typeof(value) == 'undefined') {
        return false;
    } else {
        value = value + "";
        value = value.replace(/\s/g, "");
        if (value == "") {
            return false;
        }
        return true;
    }
}
