/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(1);
	__webpack_require__(2);
	__webpack_require__(3);
	__webpack_require__(4);
	__webpack_require__(5);
	__webpack_require__(6);
	__webpack_require__(7);
	__webpack_require__(8);
	__webpack_require__(9);
	__webpack_require__(10);
	__webpack_require__(11);
	module.exports = __webpack_require__(12);


/***/ },
/* 1 */
/***/ function(module, exports) {

	/**
	 * app/微信 框架配置文件
	 * 创建：2015-11-9
	 * 更新：2016-8-30 : 以常量命名规范 代替 变量命名规范
	 */

	!function(window){
		//项目名称，组成异步地址、分享地址的一部分
		window.PROJECT_NAME = 'carguys';
		//是否为正式(生产)环境
		window.IS_FORMAL_ENV = true;
//        window.DOMAIN = 'http://carguys.hiyoo.cn';
		//域名
        window.DOMAIN = 'http://192.168.199.197';
		window.CONFIG = {
				VERSION: '1.0.0',	//app版本号，是组成本地数据库文件的名称的一部分
		 		DEBUG: IS_FORMAL_ENV ? false : true,
				/*本地数据库配置，用于缓存数据结构*/
		 		DB: {
		 			NAME: PROJECT_NAME,	//数据库名称，一般默认为  PROJECT_NAME
		 			MAIN_TABLE: 'mainTable', /*主表*/
		 			DEBUG: IS_FORMAL_ENV ? false : true		/*是否启动本地数据库调试机制，true则显示报错弹出框*/
		 		},
		 		SHARE_URL: 'http://' + (IS_FORMAL_ENV ? '' : 'test') + PROJECT_NAME + '.carguys.com/AppShare',
		 		/*异步请求配置，用于获取服务器端数据*/
		 		AJAX: {
		 		    BASE_URL: DOMAIN + '/app'
		 			//BASE_URL: DOMAIN + '/index.php/api'
		 		},
		 		AJ_PUSH: IS_FORMAL_ENV ? false : true,	/*是否绑定极光推送测试*/
		 		QIN_JIA:{
		 			APP_KEY:'d3472745b3194ce9894acb066d602352',
		 			ACCESS_SECRET:'b3bb16e0914645e492e5ae4b293db7da',
                    COMPANY_ID:'9da8f010d3f0481690cb8dadeccd47ad'
		 		},
		 		userName: 'userName',//用户手机号
		 		memberInfo:'memberInfo',//用户信息
				memberId:'memberId',//用户id
				diamonds:'diamonds',//用户id
				token:'token',//用户密钥
                token_Time:'token_Time',//用户密钥有效期
                upToken:'upToken',//上传凭证
                upToken_Time:'upToken_Time',//凭证有效期
				appVersion: 'appVersion',//版本号
				firstOpen: 'firstOpen',//是否第一次打开app
				lon: 'lon',//经度
				lat: 'lat',//纬度
				qiyuUnreadCount: 'qiyuUnreadCount',//七鱼客服未读条数
				zbVersion: 1,
                totalImage:"totalImage",
				totalFollow:"totalFollow",
				totalFan:"totalFan",
		 	};
        window.CACHE = {
            advert: "advert",	//
            advert_update: "advert_update",	//
        };
	}(window);


/***/ },
/* 2 */
/***/





/* 3 */
/***/ function(module, exports) {

	/*调试模块
	 * 
	 */
	!function(window){
		var d = {
			alt: function(msg){
				if(CONFIG.DEBUG){
					api.alert({
						title: '提示信息',
						msg: msg,
					});
				}
			},
			toast: function(msg){
				if(CONFIG.DEBUG){
					api.toast({
						location: 'top',
						msg: msg
					});
				}
			}
		};
		window.Debug = d;
	}(window);


/***/ },
/* 4 */
/***/ function(module, exports) {

	/*
	 * 模板拼接，必须先导入doT.js
	 * 创建于2016-1-10
	 */
	!function(window){
		var t = {
			html: function(selector, template, data,lazyload,lazyload_container,lazyload_selector){
				$api.html($api.dom(selector), doT.template($api.html($api.dom('[template="'+template+'"]')))(data||''));
				try{
					api.parseTapmode();
					if(lazyload && $(lazyload_selector || 'div.img') && $(lazyload_selector || 'div.img').lazyload){
						$(lazyload_selector || 'div.img').lazyload({
					      effect : "fadeIn",
					      container: $(lazyload_container || selector)
					    });
					}
				}catch(e){
					
				}
			},
			append: function(selector, template, data){
				$api.append($api.dom(selector), doT.template($api.html($api.dom('[template="'+template+'"]')))(data||''));
				try{
					api.parseTapmode();
					if(lazyload && $(lazyload_selector || 'div.img') && $(lazyload_selector || 'div.img').lazyload){
						$(lazyload_selector || 'div.img').lazyload({
					      effect : "fadeIn",
					      container: $(lazyload_container || selector)
					    });
					}
				}catch(e){
					
				}
			},
			prepend: function(selector, template, data,lazyload,lazyload_container,lazyload_selector){
				$api.prepend($api.dom(selector), doT.template($api.html($api.dom('[template="'+template+'"]')))(data||''));
				try{
					api.parseTapmode();
					if(lazyload && $(lazyload_selector || 'div.img') && $(lazyload_selector || 'div.img').lazyload){
						$(lazyload_selector || 'div.img').lazyload({
					      effect : "fadeIn",
					      container: $(lazyload_container || selector)
					    });
					}
				}catch(e){
					
				}
			}
		};
		window.T = t;
	}(window);


/***/ },
/* 5 */
/***/ function(module, exports) {

	
	/*
	 * 创建于2015-05-23
	 * DB模块封装了手机常用数据库sqlite的增删改查语句
	 * 可实现数据的本地存储，极大的简化了数据归档问题
	 *--------------------------------------------------
	 * 更新于：2016-07-27	23:04
	*/

	(function(window){
		var d = {
			init: function(args){
				/**
				 * 打开本地数据库
				 * @param  	{string} 		name			数据库名称，统一使用[CONFIG.DB.NAME]
				 * @param		{string}		path			数据库所在路径，不传时使用默认创建的路径。
				 *                         				支持 fs://、widget://等协议（如fs://user.db）
				 *                         				统一使用['fs://db/'+ CONFIG.DB.NAME +'.db']
				 * @param		{function}	success		初始化完毕后的回调
				 */
				var db = api.require('db'),
						self = this;

				db.openDatabase({
					name: args ? args.name || CONFIG.DB.NAME : CONFIG.DB.NAME,
					path: 'fs://db/'+ CONFIG.DB.NAME + '_' +  CONFIG.VERSION +'.db'
				}, function(ret, err){
					if(ret.status){
						/*数据库	 打开/创建  成功
						 * 创建主表
						 */
						self.createTable({
							table: CONFIG.DB.MAIN_TABLE,
							field: [
								'`key` varchar(100)',
								'`value` text'
							],
							success: function(){
								if(args && 'function' === typeof args.success){
									args.success();
								}
							}
						});
					}else{
						if(CONFIG.DEBUG && CONFIG.DB.DEBUG){
							var msg;
							if(err.msg){
								msg = err.msg;
							}else{
								msg = 'open database error';
							}
							api.alert({
								title: 'openDatabase提示信息',
								msg: msg
							});
						}
					}
				});
			},

			closeDatabase: function(args){
				/**
				 * 关闭数据库
				 * @param		{string}			name				数据库名称，统一使用[CONFIG.DB.NAME]
				 * @param		{function}		success			成功的回调
				 */
				var db = api.require('db'),
						self = this;

				db.closeDatabase({
					name: args ? args.name || CONFIG.DB.NAME : CONFIG.DB.NAME
				}, function(ret, err){
					if(ret.status){
						if(typeof args.success === 'function'){
							args.success();
						}
					}else{
						if(CONFIG.DEBUG && CONFIG.DB.DEBUG){
							api.alert({
								title: 'closeDatabase提示信息',
								msg: err.msg
							});
						}
					}
				});
			},

			createTable: function(args){
				/**
				 * 创建数据表
				 * @param		{string}			table				表名，统一使用[CONFIG.DB.MAIN_TABLE]
				 * @param		{array}				field				数据表的字段
				 * @param		{function}		success			成功的回调
				 */
				var self = this,
						sql = 'create table if not exists ' + args.table + '(' + args.field.join() + ')';
				this.executeSql({
					sql: sql,
					success: function(){
						if('function' === typeof args.success){
							args.success();
						}
					}
				});
			},

			executeSql: function(args) {
				/**
				 * 执行 sql
				 * @param		{string}			dbName			数据库名，统一使用[CONFIG.DB.NAME]
				 * @param		{string}			sql					SQL语句
				 * @param		{function}		success			成功的回调
				 */
				var db = api.require('db');
				db.executeSql({
					name: args.dbName || CONFIG.DB.NAME,
					sql: args.sql
				}, function(ret, err) {
					// alert('executeSql:'+$api.jsonToStr(ret||err));
					if (ret.status) {
						/*执行SQL成功*/
						if('function' === typeof args.success){
							args.success();
						}
					} else {
						/*执行SQL失败*/
						if(CONFIG.DEBUG && CONFIG.DB.DEBUG){
							var msg;
							if(err.msg){
								msg = err.msg;
							}else{
								msg = 'execute sql error';
							}
							api.alert({
								title: 'executeSQL提示信息',
								msg: msg
							});
						}
					}
				});
			},

			selectSql: function(args){
				/**
				 * 执行查询sql命令
				 *
				 * @param		{string}		dbName		数据库名，统一使用[CONFIG.DB.NAME]
				 * @param		{string}		sql				查询SQL语句
				 * @param		{function}	success		成功回调
				 * success
				 * @return	{array}			data			查询结果数据
				 *
				 */
				var db = api.require('db');
				db.selectSql({
					name: args.dbName || CONFIG.DB.NAME,
					sql: args.sql
				}, function(ret, err){
					if(ret.status){
						/*查询sql成功*/
						if('function' === typeof args.success){
							/*ret.data为查询结果(array)*/
							args.success(ret.data);
						}
					}else{
						/*查询sql失败*/
						if(CONFIG.DEBUG && CONFIG.DB.DEBUG){
							var msg;
							if(err.msg){
								msg = err.msg;
							}else{
								msg = 'select sql error';
							}
							api.alert({
								title: 'selectSQL提示信息',
								msg: msg
							});
						}
					}
				});
			},

			setValue: function(args){
				/**
				 * 缓存指定接口的数据到本地
				 * 根据指定key值获取value，每个key值由ctrl与fn组成，即对应一个接口，
				 * 所以，value的值就是该接口的缓存数据
				 *
				 * @param		{string}		key			键名
				 * @param		{string}		value		键值
				 * @param		{number}		flag		根据此值执行insert(0)或update(1)操作
				 * @param		{function}	success	成功的回调
				 *
				 */
				var self = this,
						updateSql = 'update ' + CONFIG.DB.MAIN_TABLE + " set value='" + args.value + "' where key='" + args.key + "'";

				if(args.flag){
					this.executeSql({
						sql: updateSql,
						success: args.success
					});
				}else{
					this.insert({
						data: {
							key: args.key,
							value: args.value
						}
					}, args.success);
				}
			},

			getValue: function(args){
				/**
				 * 获取对应接口的缓存数据
				 * 根据指定key值获取value，每个key值由ctrl与fn组成，即对应一个接口，
				 * 所以，value的值就是该接口的缓存数据
				 *
				 * @param		{string}			key				键名
				 * @param 	{function}		success		成功回调
				 *
				 * @return	{string}			value			对应键名的键值
				 */
				var self = this,
						sql = 'select * from ' + CONFIG.DB.MAIN_TABLE + ' where key="' + args.key + '"';
				this.selectSql({
					sql: sql,
					success: function(data){
						if(typeof args.success === 'function'){
							if(data.length > 0){
								args.success(data[0].value);
							}else{
								//返回空，只为更方便调用者判断
								args.success('');
							}
						}
					}
				});
			},

			insert: function(args){
				/**
				 * 数据插入
				 *
				 * @param		{string}		table			数据主表的名称，统一使用[CONFIG.DB.MAIN_TABLE]
				 * @param		{object}		data			将被插入数据表的数据，即接口返回的新数据将初次插入数据表
				 * @param		{function}	success		成功的回调
				 */
				var sql = 'insert into ' + (args.table || CONFIG.DB.MAIN_TABLE) + ' (' +
									(function(){
										var k = '', t;
										for(var key in args.data){
											k = k + key + ',';
										}
										t = k.slice(0, -1);
										return t;
									})() + ')' + ' values(' +
									(function(){
										var v = '';
										for(var key in args.data){
											v = v + "'" + args.data[key] + "',";
										}
										return v.slice(0, -1);
									})() + ')';
				this.executeSql({
					sql: sql,
					success: args.success
				});
			}

		};



		/*事务*/
		d.transaction = function(dbName, operation, callback){
			var db = api.require('db');
			db.transaction({
				name: dbName,
				operation: operation
			}, function(ret, err){
				if(ret.status){
					/*事务操作成功*/
					if('function' === typeof callback){
						callback();
					}
				}else{
					/*事务操作失败*/
					if(CONFIG.DB.DEBUG){
						var msg;
						if(err.msg){
							msg = err.msg;
						}else{
							msg = 'transaction operation error';
						}
						api.alert({
							title: '提示信息',
							msg: msg
						});
					}
				}
			});
		};


		window.DB = d;
	})(window);


/***/ },
/* 6 */
/***/ function(module, exports) {

	/*封装了各种常用的工具函数
	 * 2015-09-15
	 */

	/**
	 * @author					海有网络
	 * @description			封装了各种常用的工具函数
	 * @namespace				Tool
	 * @version					1.0.0
	 */

	! function(window) {
		var tl = {
			/** documented as Tool.initApp */
			initApp: function(args) {
				/**
				 * 初始化APP，即打开app后的第一个展现在用户面前的window，称为首页
				 * 首页的展现分两种模式：
				 * 	1.openWin(默认)
				 *  2.openDrawerLayout抽屉式侧滑window
				 *
				 * @method	initApp
				 * @memberof Tool
				 * @param		{object}	args								参数对象
				 * @param		{string}	args.displayType		展现的模式：win[默认] | drawerLayout
				 * @param		{string}	args.name						首页自定义名称，默认：Init
				 * @param		{string}	args.fileName				首页的 html 文件名
				 * @param		{object}	args.animation			动画参数，默认：{type: 'fade'}，具体内部参数说明参考apicloud文档
				 * @param		{object}	args.leftPane				左边侧滑 window，具体内部参数说明参考apicloud文档
				 * @param		{object}	args.rightPane			右边侧滑 window，具体内部参数说明参考apicloud文档
				 */

				if (args && args.displayType == 'drawerLayout') {
					//首页以openDrawerLayout打开
					api.openDrawerLayout({
						name: args ? args.name ? args.name : 'Init' : 'Init',
						url: api.wgtRootDir + '/' + (args ? args.fileName ? args.fileName : 'init' : 'init') + '.html',
						rect: {
							x: 0,
							y: 0,
							w: 'auto',
							h: 'auto'
						},
						bounces: false,
						slidBackEnabled: false,
						animation: args.animation || {
							type: 'fade'
						},
						leftPane: args.leftPane || '',
						rightPane: args.rightPane || '',
						reload: true
					});
				} else {
					//首页以openWin方法打开
					api.openWin({
						name: args ? args.name ? args.name : 'Init' : 'Init',
						url: api.wgtRootDir + '/' + (args ? args.fileName ? args.fileName : 'init' : 'init') + '.html',
						rect: {
							x: 0,
							y: 0,
							w: 'auto',
							h: 'auto'
						},
						bounces: false,
						slidBackEnabled: false,
						reload: false,
						animation: args ? args.animation || {
							type: 'fade'
						} : {
							type: 'fade'
						}
					});
				}
			},
			exitApp: function() {
				/**
				 * app退出逻辑，一般在 Init 首页设置
				 * @method	exitApp
				 * @memberof Tool
				 */
				api.addEventListener({
					name: 'keyback'
				}, function(ret, err) {
					api.toast({
						msg: '再按一次返回键退出',
						duration: 2000,
						location: 'bottom'
					});

					api.addEventListener({
						name: 'keyback'
					}, function(ret, err) {
						api.closeWidget({
							silent: true
						});
					});

					setTimeout(function() {
						tl.exitApp();
					}, 2000)
				});
			},
			makeCall: function(phone) {
				/**
				 * 拨打电话
				 * @method	makeCall
				 * @memberof Tool
				 * @param		{string}	phone		电话号码
				 */
				if (phone) {
					api.call({
						type: 'tel_prompt',
						number: phone
					});
				}
			},
			toast: function(msg) {
				/**
				 * 弹出一个定时自动关闭的提示框
				 * @method	toast
				 * @memberof Tool
				 * @param		{string}	msg		提示信息
				 */
				api.toast({
					msg: msg,
					duration: 2000,
					location: 'middle'
				});
			},
			removeHTMLTag: function(htmlCode) {
				/**
				 * 过滤 html 标签
				 * @method	removeHTMLTag
				 * @memberof Tool
				 * @param		{string}	htmlCode		html代码字符串
				 * @return	{string}	已过滤掉html代码的字符串
				 */
				htmlCode = htmlCode.replace(/<\/?[^>]*>/g, ''); //去除HTML tag
				htmlCode = htmlCode.replace(/[ | ]*\n/g, '\n'); //去除行尾空白
				//htmlCode = htmlCode.replace(/\n[\s| | ]*\r/g,'\n'); //去除多余空行
				htmlCode = htmlCode.replace(/&nbsp;/ig, ''); //去掉&nbsp;
				return htmlCode;
			},
			toHTML: function(str) {
				/**
				 * 将字符串中的实体字符转换为 html 代码
				 * @method	toHTML
				 * @memberof Tool
				 * @param		{string}	str		带有实体字符的 html 代码字符串
				 * @return	{string}	html 代码字符串
				 */
				if (str) {
					var regx = /&[l,g]t;|&quot;|&nbsp;|&amp;#39;|&amp;/gm,
						_html = str.replace(regx, function(match) {
							switch (match) {
								case '&amp;#39;':
									return '\'';
								case '&lt;':
									return '<';
								case '&gt;':
									return '>';
								case '&quot;':
									return '"';
								case '&nbsp;':
									return '';
								case '&amp;':
									return '&';
							}
						});
					return _html;
				} else {
					return '';
				}
			},
			imageCompressByQiNiu: function(url, mode, w, h) {
				/**
				 * 七牛图片压缩
				 * 移动端：/0/w/<Width>/h/<Height>
				 * PC端：/2/w/<Width>/h/<Height>
				 * @see 具体文档说明：{@link http://developer.qiniu.com/code/v6/api/kodo-api/image/imageview2.html}
				 *
				 * @method	imageCompressByQiNiu
				 * @memberof Tool
				 * @param		{string}	url		图片在七牛存储空间上的地址
				 * @param		{number}	mode	压缩模式
				 * @param		{number}	w			限定缩略图最大的宽度
				 * @param		{number}	h			限定缩略图最大的高度
				 * @return	{string}	图片压缩后的地址
				 */
				var str = url.substr(-10);
				if(str == 'avatar.jpg'){
					return url;
				}else{
					return url + '?imageView2/' + mode + '/w/' + w + '/h/' + h;
				}
			},
			refreshMoney: function(money, flag) {
				/*更新余额
				 * flag：0扣除金额；1增加金额
				 */
				var memberInfo = $api.getStorage('memberInfo');
				if (flag) {
					memberInfo.money = parseFloat(memberInfo.money) + parseFloat(money);
				} else {
					memberInfo.money = parseFloat(memberInfo.money) - parseFloat(money);
				}
				$api.setStorage('memberInfo', memberInfo);
				api.sendEvent({
					name: 'refreshMoney'
				});
			},
			refreshIntegral: function(integral, flag) {
				/*更新积分
				 * flag：0扣除利币；1增加利币
				 */
				var memberInfo = $api.getStorage('memberInfo');
				if (flag) {
					memberInfo.integral = parseInt(memberInfo.integral) + parseInt(integral);
				} else {
					memberInfo.integral = parseInt(memberInfo.integral) - parseInt(integral);
				}
				$api.setStorage('memberInfo', memberInfo);
				api.sendEvent({
					name: 'refreshIntegral'
				});
			},
			getSomePic: function(args) {
				/*获取多张图片
				 */
				this.getSomeMedia(args);
			},
			getSomeMedia: function(args) {
				/**
				 * 获取多张图片或视频的回调函数
				 * @callback	getSomeMediaCallback
				 * @param		{object}		ret
				 * @param		{object[]}	ret.list - 返回选定的资源信息数组
				 * @param		{string}		ret.list[].path - 资源路径，返回资源在本地的绝对路径
				 * @param		{string}		ret.list[].thumbPath - 缩略图路径，返回资源缩略图在本地的绝对路径
				 * @param		{string}		ret.list[].suffix - 文件后缀名，如：png，jpg, mp4
				 * @param		{number}		ret.list[].size - 资源大小，单位（Bytes）
				 * @param		{string}		ret.list[].time - 资源创建时间，格式：yyyy-MM-dd HH:mm:ss
				 */
				/**
				 * 获取多张图片或视频
				 * @method	getSomeMedia
				 * @memberof Tool
				 * @param  {object}    args - 参数对象
				 * @param  {number}    [args.max=5] - 最多可选的图片数
				 * @param  {object}    [args.sort] - 图片排序方式
				 * @param  {string}    [args.sort.key=time] - 按图片创建时间排序
				 * @param  {string}    [args.sort.order=desc] - 排序方式：desc(新->旧) | asc(旧->新)
				 * @param  {string}    [args.type=picture] - 返回的资源种类：all | picture | video
				 * @param  {object}    [args.scrollToBottom] - 打开媒体资源界面后间隔一段时间开始自动滚动到底部设置
				 * @param  {number}    [args.scrollToBottom.intervalTime=-1] - 打开媒体资源界面后间隔的时间开始自动滚动到底部，单位秒（s），小于零的数表示不滚动到底部
				 * @param  {boolean}   [args.scrollToBottom.anim=true] - 滚动时是否添加动画，android 平台不支持动画效果
				 * @param  {boolean}   [args.transPath=false] - 是否将相册图片地址转换为可以直接使用的本地路径地址（临时文件夹的绝对路径）
				 * @param  {getSomeMediaCallback}  args.success - 成功获取图片的回调
				 */
				var obj = api.require('UIMediaScanner'),
					sort = {
						key: 'time',
						order: 'desc'
					},
					scrollToBottom = {
						intervalTime: -1,
						anim: true
					};
				obj.open({
					type: typeof args === 'object' ? args.type || 'picture' : 'picture',
					column: 4,
					classify: true,
					max: typeof args === 'object' ? args.max || 5 : 5,
					sort: args.sort || sort,
					texts: {
						stateText: '已选择*项',
						cancelText: '取消',
						finishText: '完成'
					},
					styles: {
						bg: '#fff',
						mark: {
							icon: '',
							position: 'bottom_left',
							size: 20
						},
						nav: {
							bg: '#eee',
							stateColor: '#000',
							stateSize: 18,
							cancelBg: 'rgba(0,0,0,0)',
							cancelColor: '#000',
							cancelSize: 18,
							finishBg: 'rgba(0,0,0,0)',
							finishColor: '#000',
							finishSize: 18
						}
					},
					scrollToBottom: args.scrollToBottom || scrollToBottom,
					exchange: true
				}, function(ret) {
					var index = 0; //记录图片索引

					//闭包：将相册图片地址转换为可以直接使用的本地路径地址（临时文件夹的绝对路径）
					function transPath(path) {
						obj.transPath({
							path: path
						}, function(ret2, err) {
							if (ret) {
								ret.list[index].path = ret2.path;
								index += 1;
								if (ret.list.length > index) {
									//继续转换下一张图片路径
									transPath(ret.list[index].path);
								} else {
									//图片路径转换结束，重置索引
									index = 0;
									//执行回调，返回转换路径后的图片数组
									args.success(ret)
								}
							}
						});
					}

					if (ret.list instanceof Array && ret.list.length != 0) {
						if (args.transPath) {
							transPath(ret.list[index].path);
						} else {
							args.success(ret)
						}
					}
				});
			},
			getOnePic: function(args) {
				/*获取单张图片
				 */
				this.getOneMedia(args);
			},
			getOneMedia: function(args) {
				/**
				 * 通过系统相册或拍照获取单张图片的回调函数
				 * @callback	getOneMediaCallback
				 * @param	{object}	ret
				 * @param	{string}	ret.data - 图片路径
				 * @param	{string}	ret.base64Data - base64数据，destinationType为base64时返回
				 * @param	{number}	ret.number - 视频时长（数字类型）
				 */

				/**
				 * 通过系统相册或拍照获取单张图片
				 * @method   getOneMedia
				 * @memberof   Tool
				 * @param  {object}      args
				 * @param  {string}      [args.mediaValue=pic] - 媒体类型: pic | video
				 * @param  {string}      [args.destinationType=url] - 返回图片数据类型: url | base64
				 * @param  {string}      [args.videoQuality=medium] - 视频质量(仅ios): low | medium | high
				 * @param  {string}      [args.sourceType=library] - 图片源类型: library | camera
				 * @param  {string}      [args.encodingType=jpg] - 返回图片类型: jgp | png
				 * @param  {number}      [args.quality=50] - 图片质量，只针对jpg格式图片(0-100整数)
				 * @param  {boolean}     [args.allowEdit=false] - 是否可以选择图片后进行编辑，支持iOS及部分安卓手机
				 * @param  {getOneMediaCallback}    args.success - 成功获取多媒体资源的回调
				 */
				api.getPicture({
					mediaValue: args.mediaValue || 'pic',
					videoQuality: args.videoQuality || 'medium',
					sourceType: args.sourceType || 'library',
					encodingType: args.encodingType || 'jpg',
					destinationType: args.destinationType || 'url',
					quality: args.quality || 100,     //头像图片质量 0－100 ，原为50，现在改为100 －－WU
					allowEdit: typeof args.allowEdit === 'boolean' ? args.allowEdit : false
				}, function(ret, err) {
					if (ret) {
						args.success(ret);
					}
				});
			},
			actionSheet: function(args) {
				/**
				 * actionSheet点击按钮后的回调
				 * @callback	actionSheetCallback
				 * @param	{number}	buttonIndex	- 返回按钮点击序号，从1开始
				 */

				/**
				 * 底部弹出框
				 * @method actionSheet
				 * @memberof Tool
				 * @param  {object}    args
				 * @param  {string}    [args.title] - 标题
				 * @param  {string}    [args.cancelTitle=取消] - 取消按钮标题
				 * @param  {string}    [args.destructiveTitle] - （可选项）红色警示按钮标题，一般用于做一些删除之类操作
				 * @param  {string[]}     [args.buttons] - 按钮
				 * @param  {object}    [args.style=actionSheetStyle] - 样式设置，不传时使用默认样式
				 * @param  {actionSheetCallback}  args.success - 点击按钮后的回调
				 * @example
				 * Tool.actionSheet({
				 *   buttons: ['按钮1', '按钮2'],
				 *   success: function(buttonIndex){
				 *     switch(buttonIndex){
				 *       case 1:
				 *         //code
				 *         break;
				 *     }
				 *   }
				 * })
				 */
				var actionSheetStyle = {
					layerColor: 'rgba(0, 0, 0, 0.3)',
					itemNormalColor: '#F1F1F1',
					itemPressColor: '#007AFF',
					fontNormalColor: '#007AFF',
					fontPressColor: '#F1F1F1'
				};
				api.actionSheet({
					title: args.title || '',
					cancelTitle: args.cancelTitle || '取消',
					buttons: args.buttons,
					destructiveTitle:args.destructiveTitle,
					style: args.style || actionSheetStyle
				}, function(ret, err) {
					args.success(ret.buttonIndex);
				});
			},
			parseDate: function(timestamp) {
				/**
				 * 将时间戳转换为年、月、日、时、分、秒
				 * @method	parseDate
				 * @memberof	Tool
				 * @param		{(number|string)}	timestamp	- 时间戳
				 * @return	{object}	返回的对象包括：year、month、date、hour、minute、second
				 */
				timestamp = timestamp.toString();
				if (timestamp.length == 10) {
					/*PHP返回的时间戳长度为10，JS要求的长度必须13
					 * 若长度不足，则以0补充
					 */
					timestamp = parseInt(timestamp) * 1000;
				}
				var _d = new Date(timestamp);
				return {
					year: _d.getFullYear(),
					month: _d.getMonth() + 1,
					date: _d.getDate(),
					hour: _d.getHours(),
					minute: _d.getMinutes(),
					second: _d.getSeconds(),
				};
			},
			onCall: function() {
				var voiceMag = api.require('voiceMag');
				voiceMag.onCall(); //改为听筒播放音频
			},
			onNormal: function() {
				var voiceMag = api.require('voiceMag');
				voiceMag.onNormal(); //使用扩音器播放音频
			},
			startPlay: function(path) {
				//播放语音
				var voiceMag = api.require('voiceMag');
				voiceMag.startPlay({
					path: path
				});
			},
			stopPlay: function() {
				var voiceMag = api.require('voiceMag');
				voiceMag.stopPlay();
			},
			openPhotoBrowser: function(args) {
				/**
				 * 打开一个图片浏览器，可以 frame（全屏）的形式打开并添加到主窗口上
				 * 开发者可通过 openFrame 打开多个 frame，来自定义上下导航条的样式及其功能。
				 * 本方法支持横竖屏。加载的网络图片会被缓存到本地
				 *
				 *args 内部结构
				 * images 要读取的图片路径组成的数组，图片路径支持fs://、widget://、http://协议
				 * activeIndex[0] 当前要显示的图片在图片路径数组中的索引
				 * placeholderImg 当加载网络图片时显示的占位图路径，要求本地图片路径(widget://、fs://)
				 * bgColor['#000'] 图片浏览器背景色，支持rgb、rgba、#
				 * show 打开浏览器并显示的回调
				 * change 用户切换图片的回调
				 * click 用户单击图片浏览器的回调
				 * loadImgSuccess 网络图片下载成功的回调事件的回调
				 * longPress 用户长按图片事件的回调
				 *
				 *@return
				 * eventType 交互事件类型，取值范围如下：
				 * 		show：打开浏览器并显示
				 * 		change：用户切换图片
				 * 		click：用户单击图片浏览器
				 * 		loadImgSuccess：网络图片下载成功的回调事件
				 * 		longPress：用户长按图片事件
				 * index 数字类型；当前图片在图片路径数组中的索引
				 */
				var photoBrowser = api.require('photoBrowser');
				photoBrowser.open({
					images: args.images,
					activeIndex: args.activeIndex || 0,
					placeholderImg: args.placeholderImg || '',
					bgColor: args.bgColor || '#000'
				}, function(ret, err) {
					switch (ret.eventType) {
						case 'show':
							if (typeof args.show === 'function') {
								args.show(photoBrowser, ret.index);
							}
							break;
						case 'change':
							if (typeof args.change === 'function') {
								args.change(photoBrowser, ret.index);
							}
							break;
						case 'click':
							if (typeof args.click === 'function') {
								args.click(photoBrowser, ret.index);
							}
							break;
						case 'loadImgSuccess':
							if (typeof args.loadImgSuccess === 'function') {
								args.loadImgSuccess(photoBrowser, ret.index);
							}
							break;
						case 'longPress':
							if (typeof args.longPress === 'function') {
								args.longPress(photoBrowser, ret.index);
							}
							break;
					}
				});
			},
			cardReader: function(callback) {
				/*cardReader封装了PayPal的cardio识别库，
				 * 用户只需用摄像头扫描信用卡即可实现卡号的输入
				 *
				 *@ret
				 * 	cardNum 卡号
				 * 	expiryMonth 过期日期的月
				 * 	expiryYear 过期日期的年
				 * 	cvv cvv号
				 */
				var obj = api.require('cardReader');
				obj.open(function(ret, err) {
					if (ret.status) {
						callback(ret);
					}
				});
			},
			shareAction: function(args) {
				/*shareAction 是一个调用系统分享功能的模块，通过该模块能够分享一些最常见的文本，图片信息等
				 *
				 *args 内部结构
				 * text 要分享的文本信息
				 * type 分享文件的类型: text/image/audio/file
				 * path 分享文件的路径，要求本地路径(fs://，widget://)。Android 平台不支持 widget:// 路径
				 */
				var sharedModule = api.require("shareAction");
				sharedModule.share({
					text: args.text,
					type: args.type,
					path: args.path
				});
			},
			formatCurrency: function(num) {
				/**
				 * 将数值四舍五入(保留2位小数)后格式化成金额形式
				 * @method 		formatCurrency
				 * @memberof	Tool
				 * @param			{number}		num			原始金额数值
				 * @return		{float}			已格式化的金额数值
				 */
				num = num.toString().replace(/\$|\,/g, '');
				if (isNaN(num))
					num = "0";
				sign = (num == (num = Math.abs(num)));
				num = Math.floor(num * 100 + 0.50000000001);
				cents = num % 100;
				num = Math.floor(num / 100).toString();
				if (cents < 10)
					cents = "0" + cents;
				for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
					num = num.substring(0, num.length - (4 * i + 3)) + ',' +
					num.substring(num.length - (4 * i + 3));
				return (((sign) ? '' : '-') + num + '.' + cents);
			},
			getCacheSize: function(args) {
				/**
				 * 计算缓存大小
				 * @method	getCacheSize
				 * @memberof	Tool
				 * @param		{object}		args
				 * @param		{string}		args.container		显示缓存大小的节点的选择器标识符
				 */
				api.getCacheSize({
					sync: false
				}, function(ret, err) {
					var size = ret.size / Math.pow(1024, 2);
					$api.text($api.dom(args.container), (size ? size.toFixed(2) : 0) + 'MB');
				});
			},
			clearCache: function(args) {
				/**
				 * 清除缓存后的回调
				 * @callback		clearCacheCallback
				 */

				/**
				 * 清除缓存
				 * @method	 	clearCache
				 * @memberof	Tool
				 * @param			{object}								args
				 * @param			{string}								args.container - 清除缓存后，重新显示缓存大小的节点的选择器标识符
				 */
				var self = this;
				api.confirm({
					title: '提示信息',
					msg: '你确定要清除缓存吗？',
					buttons: ['取消', '确定']
				}, function(ret, err) {
					if (ret.buttonIndex == 2) {
						var fs = api.require('fs');
						api.showProgress({
							title: '处理中...'
						});
						//关闭本地数据库
						DB.closeDatabase({
							name: CONFIG.DB.NAME,
							success: function() {
								//删除数据库文件夹
								fs.rmdir({
									path: 'fs://db'
								}, function(ret, err) {
									if (ret.status) {
										//重新初始化数据库
										DB.init();
										//清除apicloud产生的缓存
										api.clearCache({
											timeThreshold: 0
										}, function(ret, err) {
											api.getCacheSize({
												sync: false
											}, function(ret, err) {
												api.hideProgress();
												//重新计算缓存大小
												self.getCacheSize({
													container: args.container
												});
												api.toast({
													location: 'middle',
													msg: '缓存清理完毕'
												});
											});
										});
									} else {
										api.hideProgress();
										api.toast({
											location: 'middle',
											msg: '缓存清理失败'
										});
									}
								});
							}
						});
					}
				});
			},
			loadImageAsync: function(url) {
				return new Promise(function(resolve, reject) {
					var image = new Image();

					image.onload = function() {
						resolve(image);
					};

					image.onerror = function() {
						reject(new Error('Could not load image at ' + url));
					};

					image.src = url;
				});
			}
		};
		window.Tool = tl;
	}(window);

/***/ },
/* 7 */
/***/ function(module, exports) {

	/*
	 * 数据异步请求模块3
	 * 创建于2016-9-16
	 */

	 /**
	  * @author					海有网络
	  * @description			数据异步请求模块3
	  * @namespace				ajax
	  * @version					3.0.0
	  */
	(function(window){
		var ajax = {
			args: '',
			baseUrl: '',
			method: 'post',
			timeout: 30,
			cache: true,
			report: false,
			dataType: 'json',
			showLoading: true,
			returnAll: true,
			data: '',
			before: function(args){
				/**
				 * 发起异步请求之前的逻辑处理
				 */
				if(!args.hideLoading){
					var code = ''+
					'<div class="null flex-box" style="z-index: 1;">'+
						'<div class="flex-1">'+
							'加载中...'+
						'</div>'+
					'</div>';
					try{
						if(args.container){
							$api.html($api.dom(args.container), code);
						}else{
							$api.html($api.dom('#main'), code);
						}
					}catch(e){

					}
				}
				if(!!args.showProgress){
					api.showProgress({
						title: args.showProgress.title || '加载中...',
						text: args.showProgress.text || '请稍后...',
						modal: typeof args.showProgress.modal === 'boolean' ? args.showProgress.modal : true
					});
				}
			},
            success: function(ret,args){
                 //alert(JSON.stringify(ret));
				if(parseInt(ret.statusCode) == 200){
					if(this.args.showProgress){
						api.hideProgress();
					}
					switch(parseInt(ret.body.code)){
						case 200:
							//自家服务器成功返回数据
							this.serverStatus_200(ret,args);
							break;
                        case 401://token失效，重新登录
                            api.toast({
                                msg: ret.body.msg,
                                location: 'top'
                            });
                            break;
						case 404:
							//自家服务器拒绝访问，可能原因：参数传错/传漏
							this.serverStatus_404(ret);
							break;
						case 403:
							//因权限不足，自家服务器拒绝访问，可能原因：登录信息过期/在其他端登录
							this.serverStatus_403(ret);
							break;
                        case 500://服务器错误信息
                            api.toast({
                                msg: ret.body.msg,
                                location: 'top'
                            });
                            break;
					}
					if(this.args.loadType){
						this.loadType();
					}
				}
			},
			serverStatus_200: function(ret,args){
                //alert("1111111111");
				//自家服务器返回状态码为0
				var self = this,
						jsonText,
						ct = ret.body.content,
						convertField,
						regx = /'/gm;
				if(args.cache && args.cache.key){
					//缓存数据到本地数据库
					convertField = args.cache.convertField;
					if(convertField){
						//处理需要进行转义的字段
						convertField.forEach(function(value, index){
							var arrangement = value.split('.'),
									field = ct,
									i;
							if(arrangement.length == 1){
								field[arrangement[0]] = field[arrangement[0]].replace(regx, function(match){
									switch(match){
										case "'":
											return "&apos;";
									}
								});
							}else{
								for(i = 0;i<arrangement.length;i++){
									if(i == arrangement.length - 1){
										field[arrangement[i]] = field[arrangement[i]].replace(regx, function(match){
											switch(match){
												case "'":
													return "&apos;";
											}
										});
									}else{
										field = field[arrangement[i]];
									}
								}
							}
						});
					}
					jsonText = JSON.stringify(ret.body.content);
					/*缓存服务器数据*/
					if(this.localCache != jsonText){
						/*对比数据*/
						DB.setValue({
							key: self.args.cache.key,
							value: jsonText,
							flag: self.localCache ? 1 : 0
						});
					}
				}
				//alert(JSON.stringify(ret));
				if(typeof args.success == 'function'){
                    args.success(ret.body);
				}
			},
			serverStatus_404: function(ret,args){
				//自家服务器返回状态码为404
				if(typeof args._404 === 'function'){
                    args._404(ret.body.msg);
				}else{
					if(args.showError){
						if(ret.body.msg){
							api.toast({
								msg: ret.body.msg,
								location: 'bottom',
								duration: 3000
							});
						}else{
							api.toast({
								msg: '服务器拒绝访问~',
								location: 'bottom',
								duration: 2000
							});
						}
					}
				}
			},
			serverStatus_403: function(ret,args){
				//自家服务器返回状态码为403
				if(typeof args._403 === 'function'){
                    args._403();
				}else{
					var logints = $api.getStorage('logints'),
							nowts = new Date().getTime();
					/*验证登录时间戳*/
					if(logints){
						if('string' === typeof logints){
							logints = parseInt(logints);
						}
						if(nowts-logints < 1000*60*60*24*30){
							api.alert({
								title: '提示信息',
								msg: '该账号已在另一设备上登录，你无法进行相关操作，请重新登录'
							}, function(ret,err){
								relogin();
							});
						}else{
							api.alert({
								title: '提示信息',
								msg: '你的账户信息已过期，请重新登陆'
							}, function(ret,err){
								relogin();
							});
						}
					}else{
						api.alert({
							title: '提示信息',
							msg: '请先登录'
						}, function(ret, err){
							relogin();
						});
					}
				}
			},
			loadType: function(){
				//数据异步请求完成后，页面UI后续处理
				switch(this.args.loadType){
					case 1:
						/*去除下拉刷新样式*/
						api.refreshHeaderLoadDone();
						break;
					case 2:
						/*scrolltobottom事件, 去除“加载中...”UI*/
						$api.remove($api.dom('.load-more'));
						break;
				}
			},
			error: function(err){
				if(err){
					console.log(JSON.stringify(err, null, 2))
				}
				//异步请求失败
				api.hideProgress();
				if(this.args.loadType){
					this.loadType();
				}
				var msg =
						(typeof err.statusCode === 'undefined' ? '' : err.statusCode + '/') +
						(typeof err.code === 'undefined' ? '' : err.code + '-') +
						(err.msg ? err.msg : '');
			},
			errorStatusCode_0: function(err){
				//异步请求超时，或网络有问题
				switch(parseInt(err.code)){
					case 0:
						//网络有问题
						api.toast({
							msg: '连接错误，请检查网络或者请求配置是否正确',
							location: 'top'
						});
						break;
					case 1:
						//请求超时
						api.toast({
							msg: '网络请求超时，请稍后重试',
							location: 'top'
						});
						break;
				}
			},
			errorStatusCode_500: function(err){
				//服务器遇到了意料不到的情况，不能完成客户的请求

			},
			get: function(args){
				/**
				 * 成功返回缓存数据的回调处理
				 * @callback   getCacheCallback
				 * @param    {object}    cache - 对应接口的本地缓存对象
				 *
				 * 服务器成功返回数据的回调处理
				 * @callback   successCallback
				 * @param    {object}    ct - 对应接口主内容
				 * @param    {object}    cache - 对应接口的本地缓存数据
				 *
				 * 服务器拒绝访问的回调处理
				 * @callback   _404Callback
				 *
				 * 权限不足的回调处理
				 * @callback   _403Callback
				 */

				 /**
				  * 异步请求方法
				  * @method     get
				  * @memberof   ajax
				  * @param      {object}                args
				  * @param      {string}                args.ctrl - 请求接口
				  * @param      {string}                args.fn - 接口方法
				  * @param      {object}                args.cache - 是否使用缓存机制(db模块)
				  * @param      {string}                args.cache.key - 缓存的键值
				  * @param      {getCacheCallback}      args.cache.getCache - 成功返回缓存数据的回调处理
				  * @param      {number}                args.timeout - 异步请求超时设定
				  * @param      {string}                [args.dataType=json] - 数据返回格式
				  * @param      {boolean}               [args.report=false] - 返回请求进度
				  * @param      {string}                args.tag - ajax标识，用于种植异步
				  * @param      {object}                args.data - 接口方法参数
				  * @param      {object}                args.data.values - 以表单方式提交参数(JSON对象)
				  * @param      {object}                args.showProgress - 是否使用菊花进度UI
				  * @param      {string}                [args.showProgress.title=加载中...] - 标题
				  * @param      {string}                [args.showProgress.text=请稍后...] - 内容
				  * @param      {boolean}               [args.showProgress.modal=true] - 是否模态，模态时整个页面将不可交互
				  * @param      {string}                [args.container=#main] - 模板渲染的父节点
				  * @param      {number}                [args.loadType=0] - 数据加载类型:
				  *                                                       0：不填该参数，不做任何操作
				  *                                                       1：下拉刷新
				  *                                                       2：上拉加载更多
				  * @param      {boolean}               [args.hideLoading=false] - 是否隐藏"加载中..."占位代码
				  * @param      {boolean}               [args.showError=false] - 请求失败后(404)，是否显示错误信息
				  * @param      {successCallback}       args.success - 200(服务器成功返回数据)回调处理
				  * @param      {_404Callback}          args._404 - 404(服务器拒绝访问)回调处理
				  * @param      {_403Callback}          args._403 - 403(权限不足)回调处理
					*/


				var self = this;
				this.args = args;

				this.before(args);
				DB.getValue({
					key: args.cache ? args.cache.key : 'null',
					success: function(cache){
						var _url;
						if(cache){
							self.localCache = cache;
							if(args.cache && typeof args.cache.getCache === 'function'){
								args.cache.getCache(cache);
							}
						}else{
							self.localCache = '';
						}
						if(args.url){
							_url = args.url;
						}else{
							args.url = _url = CONFIG.AJAX.BASE_URL + '/' + args.ctrl + '/' + args.fn;
						}
						//alert(_url);
						api.ajax({
							url: _url,
							method: args.method || self.method,
							cache: false,
                            headers: {
                                token: $api.getStorage(CONFIG.token)
                            },
							report: self.report,
							timeout: args.timeout || self.timeout,
							tag:args.tag,
							dataType: args.dataType || self.dataType,
							returnAll: self.returnAll,
							data: (!!args.data ? args.data : '')
						}, function(ret, err){
							/*jsonp格式转换*/
							if(self.dataType === 'text'){
								try{
									ret.body = $api.strToJson(ret.body.slice(ret.body.indexOf('{'), -2));
								}catch(e){

								}
							}

							if(CONFIG.DEBUG){
								if(args.test){
									Debug.alt('ret'+$api.jsonToStr(ret) + '      err' + $api.jsonToStr(err));
								}
							}
							console.log('args: ' + JSON.stringify(args || '', null, 2))
							if(ret){
								if(args && args.fn == 'getAreaList') {
								}else {
									console.log("ret: " + JSON.stringify(ret, null, 2))
								}
								self.success(ret,args);
                                //args.success(ret.body);
							}else{
								self.error(err);
							}
						});
					}
				});
			},
			cancel : function(tag){
				if(tag){
					api.cancelAjax({
					    tag: tag
					});
				}
			}
		};

		window.ajax = ajax;

	})(window);


/***/ },
/* 8 */
/***/ function(module, exports) {

	/*
	 * 作用：页面刷新
	 * 创建于 2015-7-17 21:14
	 * 更新：2016-9-24
	 */

	/**
	 * @author				海有网络
	 * @description		刷新模块
	 * @namespace			Refresh
	 * @version				3.0.0
	 */

	!function(window){
		var c = {
			init: function(args){
				/**
				 * 成功刷新的回调
				 * @callback		refreshCallback
				 */

				/**
				 * 初始化下拉刷新功能
				 * @method			init
				 * @memberof		Refresh
				 * @param      	{string}                args.ctrl - 请求接口
				 * @param      	{string}                args.fn - 接口方法
				 * @param			 	{object}								args.values - 接口参数
				 * @param				{string}								[args.textColor=#666] - 提示文字的颜色
				 * @param				{string}								args.field - 异步返回的ct里，需要被遍历合成模板的字段，如：ct[field]
				 * @param      	{boolean}               [args.showError=false] - 请求失败后(404)，是否显示错误信息
				 * @param				{string}								[args.container=#main] - 模板渲染的父节点
				 * @param				{string}								[args.template=main] - 模板名称
				 * @param				{refreshCallback}				args.success - 成功刷新的回调
				 */


				api.setRefreshHeaderInfo({
				    visible: true,
				    loadingImg: 'widget://res/icon-refresh.png',
				    bgColor: 'rgba(0,0,0,0)',
				    textColor: args.textColor || '#666',
				    textDown: '下拉刷新...',
				    textUp: '松开刷新...',
				    showTime: true
				}, function(ret, err){
					if('none' === api.connectionType){
						api.toast({
							msg: '网络无法连接，请检查网络设备是否正常',
							location: 'bottom',
							duration: 2000
						});
						api.refreshHeaderLoadDone();
						return;
					}
					if(args && args.values){
						if(args.values.id && args.values.token){
							if($api.getStorage('memberInfo')){
								args.values.id = $api.getStorage('memberId');
								args.values.token = $api.getStorage('token');
							}else{
								Tool.toast('请先登录');
								api.refreshHeaderLoadDone();
								return;
							}
						}
					}
					ajax.get({
						ctrl: args.ctrl,
						fn: args.fn,
						data: {
							values: args.values
						},
						hideLoading: true,
						showError: args.showError,
						loadType: 1, //下拉刷新类型
						success: function(ct){
							// $api.html($api.dom(args.container||'#main'), doT.template($api.html($api.dom('[template='+(args.template||'main')+']')))(args.field ? ct[args.field] : ct));
							T.html(args.container||'#main', args.template||'main', args.field ? ct[args.field] : ct);
							api.parseTapmode();
							if('function' === typeof args.success){
								args.success();
							}
						}
					});
				});
			}
		};
		window.Refresh = c;
	}(window);


/***/ },
/* 9 */
/***/ function(module, exports) {

	/*
	 * 作用：页面滚动的底部时，加载更多信息
	 * 创建于 2015-7-8 22：18
	 */

	!function(window){
		var c = {
			init: function(args, callback){
				/*
				 * 参数 json args
				 * 				string ctrl
				 * 				string fn
				 * 				json values //异步请求参数
				 * 				boolean showError
				 * 				boolean test
				 *				string template 渲染模板
				 *				string wrapper 渲染父节点, 模板的包裹层节点
				 *				number countType 
				 * 					0 默认统计模式，page/pagesize并用;
				 * 					1 时间戳模式，以时间戳为标识获取更多数据;
				 *				function count 自定义判断加载条件是否符合，针对特殊场景，可为空
				 *					return t{	
				 *						number status (0:马上终止执行下面的逻辑)
				 *						json values	异步请求所需的参数(status=1:返回values)
				 *					}
				 *				string field 异步返回的ct里，需要被遍历合成模板的字段，如：ct[field]
				 *				string countSelector 通过该css选择器获取当前节点数，判断是否符合加载下一个分页数据的条件
				 * 				
				 */
				api.addEventListener({
					name: 'scrolltobottom'
				}, function(ret, err){

					/*判断是否加载中*/
					var loadMoreDom = $api.dom('.load-more');
					if(loadMoreDom){
						return;
					}
					//判读用户是否信息
					if(args && args.values){
						if(args.values.id && args.values.token){
							if($api.getStorage('memberInfo')){
								args.values.id = $api.getStorage('memberId');
								args.values.token = $api.getStorage('token');
							}else{
								Tool.toast('请先登录');
								return;
							}
						}
					}
					if('function' === typeof args.count){
						var t = args.count();
						if(t && t.status){
							if(!args.values){
								args.values = {};
							}
							for(var key in t.values){
								args.values[key] = t.values[key];
							}
						}else{
							return;
						}
					}else{
						if(args.countType){
							/*使用时间戳统计模式
								获取时间戳
							*/
							args.values.time = $api.attr($api.dom(args.countSelector || '#main > div:last-child'), 'timestamp');
						}else{
							/*使用默认统计模式page/pagesize*/
							try{
								var listDoms = $api.domAll(args.countSelector || '#main > div');
								if(listDoms.length == 0 || listDoms.length%10 != 0){
									return;
								}else{
									args.values.page = listDoms.length/10+1;
								}
							}catch(e){
								return;
							}		
						}
					}
						
//					 Debug.alt(JSON.stringify(args.values,null,2));
					/*渲染“加载更多”UI*/
					var loadMoreCode = ''+
							'<div class="load-more">'+
								'正在加载...'+
							'</div>';
					$api.append($api.dom('#main'), loadMoreCode);
					// alert($api.jsonToStr(args.values))
					ajax.get({
						ctrl: args.ctrl,
						fn: args.fn,
						data: {
							values: args.values
						},
						hideLoading: true,
						showError: args.showError,
						test: args.test,
						loadType: 2, //scrolltobottom类型
						success: function(ct){
							if(args.field){
								ct = ct[args.field];
							}
							if(ct instanceof Array && ct.length!=0){
								$api.append($api.dom(args.wrapper||'#main'), doT.template($api.html($api.dom('[template=' + (args.template || 'list') + ']')))(ct));
								api.parseTapmode();
								if(typeof callback === 'function'){
									callback(ct, args.values.page);
								}
							}else{
								api.toast({
									msg: '已经没有更多内容了',
									location: 'bottom',
									duration: 2000
								});
							}
						}
					});
				});
			}
		};
		window.LoadMore = c;
	}(window);

/***/ },
/* 10 */
/***/ function(module, exports) {

	/**
	 * 2016-09-25
	 */

	/**
	 * @author          海有网络
	 * @description     封装photoBrowser模块常用方法
	 * @namespace       PhotoBrowser
	 * @version         1.0.0
	 */

	! function(window) {
	  var pb = {
	    open: function(args) {
	      /**
	       * 打开图片浏览器后的回调事件
	       * @callback    showCallback
	       *
	       * 用户切换图片的回调事件
	       * @callback    changeCallback
	       * @param       {number}              index - 当前图片在图片路径数组中的索引
	       *
	       * 用户单击图片浏览器的回调事件
	       * @callback    clickCallback
	       * @param       {number}              index - 当前图片在图片路径数组中的索引
	       *
	       * 网络图片下载成功的回调事件
	       * @callback    loadImgSuccessCallback
	       * @param       {number}              index - 当前图片在图片路径数组中的索引
	       *
	       * 网络图片下载失败的回调事件
	       * @callback    loadImgFailCallback
	       * @param       {number}              index - 当前图片在图片路径数组中的索引
	       *
	       * 用户长按图片的回调事件
	       * @callback    longPressCallback
	       * @param       {number}              index - 当前图片在图片路径数组中的索引
	       */

	      /**
	       * 打开图片浏览器
	       * @method      open
	       * @memberof    PhotoBrowser
	       * @param       {object}          args
	       * @param       {object[]}        args.images - 要读取的图片路径组成的数组，图片路径支持 fs://、http:// 协议
	       * @param       {number}          [args.activeIndex=0] - 当前要显示的图片在图片路径数组中的索引
	       * @param       {string}          args.placeholderImg - 当加载网络图片时显示的占位图路径，要求本地图片路径（widget://、fs://）
	       * @param       {string}          [args.bgColor=#000] - 图片浏览器背景色，支持 rgb、rgba、#
	       * @param       {boolean}         [args.zoomEnabled=true] - 是否打开缩放手势识别功能（随手势放大缩小图片）
	       * @param       {showCallback}              打开图片浏览器后的回调事件
	       * @param       {changeCallback}            用户切换图片的回调事件
	       * @param       {clickCallback}             用户单击图片浏览器的回调事件
	       * @param       {loadImgSuccessCallback}    网络图片下载成功的回调事件
	       * @param       {loadImgFailCallback}       网络图片下载失败的回调事件
	       * @param       {longPressCallback}         用户长按图片的回调事件
	       */
	      var photoBrowser = api.require('photoBrowser');
	      photoBrowser.open({
	        images: args.images,
	        activeIndex: args.activeIndex || 0,
	        placeholderImg: args.placeholderImg || '',
	        bgColor: args.bgColor || '#000',
	        zoomEnabled: typeof args.zoomEnabled == 'boolean' ? args.zoomEnabled : true
	      }, function(ret, err) {
	        switch (ret.eventType) {
	          case 'show':
	            if (typeof args.show === 'function') {
	              args.show();
	            }
	            break;
	          case 'change':
	            if (typeof args.change === 'function') {
	              args.change(ret.index);
	            }
	            break;
	          case 'click':
	            if (typeof args.click === 'function') {
	              args.click(ret.index);
	            }
	            break;
	          case 'loadImgSuccess':
	            if (typeof args.loadImgSuccess === 'function') {
	              args.loadImgSuccess(ret.index);
	            }
	            break;
	          case 'loadImgFail':
	            if (typeof args.loadImgFail === 'function') {
	              args.loadImgFail(ret.index);
	            }
	            break;
	          case 'longPress':
	            if (typeof args.longPress === 'function') {
	              args.longPress(ret.index);
	            }
	            break;
	        }
	      });
	    },
	    close: function(){
	      var photoBrowser = api.require('photoBrowser');
	      photoBrowser.close();
	    },
	    show: function(){
	      var photoBrowser = api.require('photoBrowser');
	      photoBrowser.show();
	    },
	    hide: function(){
	      var photoBrowser = api.require('photoBrowser');
	      photoBrowser.hide();
	    }
	  };

	  window.PhotoBrowser = pb;
	}(window);


/***/ },
/* 11 */
/***/
/* 12 */
/***/ function(module, exports) {

	
	/*表单字段验证
	 * 创建于2016-1-27
	 */

	!function(window){
		var f = {
		isPhone: function(val){
			if(val && /^1[3,5,7,8]\d{9}$/.test(val)){
				return true;
			}else{
				return false;
			}
		},
		isEmail: function(val){
			var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
			if(val && reg.test(val)){
				return true;
			}else{
				return false;
			}
		}
	};
		
		window.Former = f;
	}(window);


/***/ }
/******/ ]);


/*静默更新*/
function smartUpdateFinish(){
	api.addEventListener({
		name:'smartupdatefinish'
	},function(ret,err){
		api.alert({
			title:'提示',
			msg:'新的更新包已经安装成功，重启后生效'
		},function(ret,err){
			api.closeWidget({
				id:'A6937764463108',
				silent:true
			});
		});
	});
}

//获取用户信息
function memberInfo(callback) {
	if($api.getStorage(CONFIG.memberId) && $api.getStorage(CONFIG.token)) {
		var ctrl = 'api/user',
				fn = 'info';
		ajax.get({
			ctrl: ctrl,
			fn: fn,
			success: function(ct) {
				$api.setStorage(CONFIG.memberInfo, ct.user);
				if(typeof callback == 'function') {
					callback(ct);
				}
			}
		});
	}
}

//获取关联用户信息
function memberRelateInfo(callback) {
    if($api.getStorage(CONFIG.memberId) && $api.getStorage(CONFIG.token)) {
        var ctrl = 'api/user',
            fn = 'relateInfo';
        ajax.get({
            ctrl: ctrl,
            fn: fn,
            success: function(ct) {
                if(typeof callback == 'function') {
                    callback(ct);
                }
            }
        });
    }
}

//极光推送
function jpush(tags, callback) {
	var alias = $api.getStorage(CONFIG.memberInfo).username;
	var param = {
		alias: alias,
		tags: tags
	};
	JPush.init(function(ret) {	
//		Debug.alt('初始化成功!');
		JPush.bindAliasAndTags(param, function() {
//			Debug.alt('绑定别名成功')
			JPush.getRegistrationId(function(ret) {
//				Debug.alt('绑定jpush成功RegistrationId:' + JSON.stringify(ret))
				if(ret && ret.id) {
					updateRegistrationId(ret.id, callback);
				}
			});
		});
		JPush.setListener(function(ret) {
			jpushListen(ret);
		});
		JPush.getDataByTouchNotification(function(ret) {
//			jpushListen(ret);
			if(ret) {
				if(ret.extra) {
					var ct = ret.extra;
					if (typeof ret.extra == "string") {
						ct = $api.strToJson(ret.extra);
					}
					if(ct.status) {
						var memberInfo = $api.getStorage(CONFIG.memberInfo);
						switch(ct.status) {
							//房间
							case 'roomnews'://房间 公告
								break;
							case 'roombans'://房间 禁停
								break;
							//跳转到系统消息
							case 'withdraw': //提现消息
							case 'live': 		 //直播消息
							case 'recharge': //充值消息
							case 'systemnews'://后台发送消息
								openWin('msg','msg','消息','msg','msg');
								break;
						}
					}
				}
			}
		});
	});
}

//绑定极光推送
function setAliasAndTag(param) {
	var ajpush = api.require('ajpush');
	ajpush.bindAliasAndTags(param, function(ret, err) {
		if (ret&&ret.statusCode == '6002') {
			setAliasAndTag(param);
		}
	});
}

//取消极光推送
function updateRegistrationId(rid, callback, showProgress) {
	if($api.getStorage(CONFIG.memberId) && $api.getStorage(CONFIG.token)) {
		ajax.get({
//			ctrl: 'zhiboApp',
//			fn: 'updateRegistrationId',
			ctrl: 'zhiboApp',
			fn: 'updateRegistrationId',
			data: {
				values: {
					id: $api.getStorage(CONFIG.memberId),
					token: $api.getStorage(CONFIG.token),
					rid: rid
				}
			},
			showProgress: showProgress ? true : false,
			showError: true,
			hideLoading: true,
			success:function() {
				if(typeof callback == 'function') {
					callback();
				}
			}
		});
	}
}



//退出登录
function relogin() {
	var ajpush = api.require('ajpush');
	var alias = 0;
	var tag = 'logout';
	var param = {
		alias: alias,
		tags: [tag]
	};
	setAliasAndTag(param);
	$api.rmStorage(CONFIG.memberId);
	$api.rmStorage(CONFIG.token);
	$api.rmStorage(CONFIG.memberInfo);
	api.sendEvent({
		name: 'relogin'
	});
	if(api.winName != 'root') {
		api.closeToWin({
			name: 'root'
		});
//		api.closeToWin({
//			name: 'root'
//		});
	}
}

/*格式时间*/
function formatDate(t, format, flag, flag2) {
	/*string format 年 Y 月 M 日 D 时 h 分 m 秒 s 例如 YMDhms
	 * 不填 则 采用动态返回 即当天时间隐藏月份日期  当年时间隐藏年份
	 */
	if (typeof t === 'string') {
		var t = t.replace(/-/g, '/');
		t = new Date(t);
		var now = new Date();
		var month = (t.getMonth() + 1) < 10 ? '0' + (t.getMonth() + 1) : t.getMonth() + 1;
		var date = t.getDate() < 10 ? '0' + t.getDate() : t.getDate();
		var hours = t.getHours() < 10 ? '0' + t.getHours() : t.getHours();
		var min = t.getMinutes() < 10 ? '0' + t.getMinutes() : t.getMinutes();
		var sec = t.getSeconds() < 10 ? '0' + t.getSeconds() : t.getSeconds();
		var result = '';
		var f = flag ? flag : '-';
		var f2 = flag2 ? flag2 : ':';
		if (format) {
			if (format.indexOf('Y') >= 0) {
				result += t.getFullYear();
			}
			if (format.indexOf('M') >= 0 && format.indexOf('Y') < 0) {
				result += month;
			} else if (format.indexOf('M') >= 0) {
				result += f + month;
			}
			if (format.indexOf('D') >= 0) {
				result += f + date;
			}
			if (format.indexOf('h') >= 0 && format.indexOf('D') < 0) {
				result += hours;
			} else if (format.indexOf('h') >= 0) {
				result += ' ' + hours;
			}
			if (format.indexOf('m') >= 0) {
				result += f2 + min;
			}
			if (format.indexOf('s') > 0) {
				result += f2 + sec;
			}
			return result;
		} else {
			if (t.getFullYear() == now.getFullYear()) {
				if (t.getDate() == now.getDate() && t.getMonth() == now.getMonth()) {
					return hours + ':' + min;
				} else {
					return month + '-' + date;
				}
			} else {
				return t.getFullYear() + '-' + month + '-' + date;
			}
		}
	}
}









//格式化金额
function fmoney(s, n) { 
	console.log(typeof s)
	n = n > 0 && n <= 20 ? n : 2; 
	s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + ""; 
	var l = s.split(".")[0].split("").reverse(), r = s.split(".")[1]; 
	t = ""; 
	for (i = 0; i < l.length; i++) { 
	t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : ""); 
	} 
	return t.split("").reverse().join("") + "." + r; 
}


/*聊天数据表处理 start*/
function createTable(callback){
	DB.createTable({
		table: table,
		field: ['memberid', 'roomid', 'type', 'content', 'createdtime'],
		success: function(){
//			api.toast({
//				location: 'top',
//				msg: '创建表成功'
//			});
			if(typeof callback == 'function'){
				callback();
			}
		}
	})
}

function insertIntoTable(data){
	DB.insert({
		table: table,
		data: data,
		success: function(){
//			api.toast({
//				location: 'top',
//				msg: '数据插入成功'
//			});
		}
	})
}





function selectTable(){
	DB.selectSql({
		sql: 'select * from ' + table + ';',
		success: function(data){
			if(data instanceof Array && data.length > 0){
				ajax.get({
					ctrl: 'zhiboApp',
					fn: 'savemessage',
					data: {
						values: {
							id: values.id,
							token: values.token,
							roomid: values.roomid,
							content: data
						}
					},
					hideLoading: true,
					showError: true,
					showProgress: false,
					success:function(ct){
						Debug.toast('保存成功');
						clearTable();
					}
				});
			}
		}
	})
}

function clearTable(){
	DB.executeSql({
		sql: 'delete from ' + table + ';',
		success: function(){
			Debug.toast('清空数据表成功');
		}
	})
}




//一行字体溢出时显示省略号
function ellipsisOne(dom) {
	var dom = dom ? dom : '.text-overflow';
	if(!$(dom)) return;
	if($(dom).html() == '') return;
	$(dom).ellipsis();
}



// 万位数格式化
function parseWan(num) {
			num = parseInt(num);
			var result = 0;
			if(isNaN(num)) {
				return result;
			}
			if(num > 9999) {
				result = (num / 10000).toFixed(1) + '万';
			} else {
				result = num;
			}
			return result;
		}
		
		
		//加密函数
		function tt(){
		
			var timestamp = Date.parse(new Date());
			timestamp = $api.trim(timestamp/1000);
			timestamp=timestamp.substring(0,timestamp.length-2);
			timestamp=timestamp.replace(/0/g, "a");
			timestamp=timestamp.replace(/1/g, "e");
			timestamp=timestamp.replace(/2/g, "e");
			timestamp=timestamp.replace(/3/g, "i");
			timestamp=timestamp.replace(/4/g, "a");
			timestamp=timestamp.replace(/5/g, "b");
			timestamp=timestamp.replace(/6/g, "c");
			timestamp=timestamp.replace(/7/g, "d");
			timestamp=timestamp.replace(/8/g, "d");
			timestamp=timestamp.replace(/9/g, "g");
			return timestamp;
		}



function uuid(len, radix) {
    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
    var uuid = [], i;
    radix = radix || chars.length;

    if (len) {
        // Compact form
        for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random()*radix];
    } else {
        // rfc4122, version 4 form
        var r;

        // rfc4122 requires these characters
        uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
        uuid[14] = '4';

        // Fill in random data.  At i==19 set the high bits of clock sequence as
        // per rfc4122, sec. 4.1.5
        for (i = 0; i < 36; i++) {
            if (!uuid[i]) {
                r = 0 | Math.random()*16;
                uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
            }
        }
    }

    return uuid.join('');
}

function closeWin(){
    api.closeWin();
}

function getUpToken(){
    var upToken=$api.getStorage(CONFIG.upToken);//加上有效期
    var upToken_Time=$api.getStorage(CONFIG.upToken_Time);//加上有效期
    if(!upToken || !upToken_Time){
        return requestToken();
    }else{
        if(((new Date().getTime()-upToken_Time)/(1000*60*60))>1){
            return requestToken();
		}
        return upToken;
    }
}

function requestToken(){
	//alert("requestTokenrequestToken");
    ajax.get({
        ctrl: 'api/upload',
        fn: 'uptoken',
        success: function(ct){
            alert(ct.uptoken);
            if(ct.code=="200"){
                upToken=ct.uptoken;
                $api.setStorage(CONFIG.upToken,upToken);
                $api.setStorage(CONFIG.upToken_Time,new Date().getTime());
                return upToken;
            }
        }
    });
}


function openWin(moudel,name,rect,pageParam,delay) {
    delay=0;
    api.openWin({
        name: moudel+'_'+name,
        url: api.wgtRootDir + '/html/'+moudel+'/'+name+'.html',
        rect:rect,
        pageParam:pageParam,
        delay: api.systemType == 'ios' ? delay : 0
    });
}

function openFrame(moudel,name,rect,pageParam){
    api.openFrame({
        name: moudel+'_'+name,
        url: api.wgtRootDir + '/html/'+moudel+'/'+name+'.html',
        rect: rect,
        pageParam:pageParam || {},
    })
}

/*function openFrame(frameName,url,furl,bounces,type,frameParam){
    api.openFrame({
        name: frameName,
        url: api.wgtRootDir + '/html/' + url + '/' + furl + '.html',
        bounces:bounces || false,
        pageParam:frameParam || {},
        animation:{
            type: type ||"push",
            subType:"from_right",
            duration: 300
        }
    })
}*/

